var APP_DATA = {
  "scenes": [
    {
      "id": "0-_0002_panorama4png",
      "name": "_0002_Panorama4.png",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.11136615790000093,
        "pitch": 0,
        "fov": 1.592602508703473
      },
      "linkHotspots": [],
      "infoHotspots": [
        {
          "yaw": 0.09310272249100393,
          "pitch": -0.11222913668685663,
          "title": "fantasiewald",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
